import React from "react"
import ReactDOM from "react-dom"
import { App } from "./components/app"

document.body.style.backgroundColor = "#e5e5e5";

ReactDOM.render(<App />, document.querySelector("#root"))
